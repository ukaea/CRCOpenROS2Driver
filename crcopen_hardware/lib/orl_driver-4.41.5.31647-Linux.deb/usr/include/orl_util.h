/*    This  material  is the exclusive property of Comau S.p.A.  and must be
**    returned   to   Comau   S.p.A.,   Robotics  Division,  Software  Group
**    immediately   upon   request.    This  material  and  the  information
**    illustrated or contained herein may not be used, reproduced, stored in
**    a retrieval system, or transmitted in whole or in part in  any  way  -
**    electronic, mechanical, photocopying, recording, or otherwise, without
**    the prior written consent of Comau S.p.A..
**
**                          All Rights Reserved
**                          Copyright (C)  2022
**                             Comau S.p.A.
*/

#ifndef __ORL_UTIL_H
#define __ORL_UTIL_H

    /* Verbosity level */
    #define ORL_VERB_OFF                    0
    #define ORL_VERB_ON                     1

    /* Response */
    #define ORL_OK                          0
    #define ORL_ERR_OFFSET              -1000
    #define ORL_ERR                        (-1 + ORL_ERR_OFFSET)
    #define ORL_ERR_INVALID_ARG            (-2 + ORL_ERR_OFFSET)
    #define ORL_ERR_UNINIT                 (-3 + ORL_ERR_OFFSET)
    #define ORL_ERR_COMMDROP               (-4 + ORL_ERR_OFFSET)

    /* Axis Openness */
    #define ORL_AXISOPEN                    1
    #define ORL_AXISCLOSED                  0

    /* Open Modality */
    #define ORL_LISTEN                      0
    #define ORL_CURR_FULL                   1
    #define ORL_CURR_FULL_SB               11
    #define ORL_CURR_SLAVE                  2
    #define ORL_CURR_SLAVE_SB              12
    #define ORL_SPD_FULL                    3
    #define ORL_SPD_FULL_SB                13
    #define ORL_POS_ABSOLUTE                4
    #define ORL_POS_RELATIVE                5
    #define ORL_SPD_SLAVE                   6
    #define ORL_SPD_SLAVE_SB               16
    #define ORL_POS_ADDITIVE                7
    #define ORL_POS_ADDITIVE_SB            17
    #define ORL_POS_ADDITIVE_SBE          170

    /* Controllers labels */
    #define ORL_CNTRL1                      0
    #define ORL_CNTRL_MAX                   1

    /* Arm label */
    #define ORL_ARM1                        0
    #define ORL_ARM2                        1
    #define ORL_ARM3                        2
    #define ORL_ARM4                        3
    #define ORL_ARM_MAX                     4

    /* Axis label */
    #define ORL_AXIS1                       0
    #define ORL_AXIS2                       1
    #define ORL_AXIS3                       2
    #define ORL_AXIS4                       3
    #define ORL_AXIS5                       4
    #define ORL_AXIS6                       5
    #define ORL_AXIS7                       6
    #define ORL_AXIS8                       7
    #define ORL_AXIS9                       8
    #define ORL_AXIS10                      9
    #define ORL_AXIS_MAX                   10

    /* Callback period */
    #define ORL_T_400US                     0
    #define ORL_T_2MS                       1
    #define ORL_T_4MS                       2
    #define ORL_T_8MS                       3
    #define ORL_T_16MS                      4

    /* Services */
    #define ORL_BASEFRAME                   0
    #define ORL_TOOLFRAME                   1
    #define ORL_USERFRAME                   2

    #define ORL_IDL2COMP                    0
    #define ORL_COMP2IDL                    1

    #define ORL_DRIVEOFF                    1
    #define ORL_DRIVINGON                   2
    #define ORL_DRIVINGOFF                  3
    #define ORL_DRIVEON                     4

    #define ORL_MODSTS_T1                   0
    #define ORL_MODSTS_T2                   1
    #define ORL_MODSTS_AL                   2
    #define ORL_MODSTS_AR                   3

#endif