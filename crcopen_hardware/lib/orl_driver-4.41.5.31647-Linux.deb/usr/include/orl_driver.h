//    This  material  is the exclusive property of Comau S.p.A.  and must be
//    returned   to   Comau   S.p.A.,   Robotics  Division,  Software  Group
//    immediately   upon   request.    This  material  and  the  information
//    illustrated or contained herein may not be used, reproduced, stored in
//    a retrieval system, or transmitted in whole or in part in  any  way  -
//    electronic, mechanical, photocopying, recording, or otherwise, without
//    the prior written consent of Comau S.p.A..
//
//                          All Rights Reserved
//                          Copyright (C)  2023
//                             Comau S.p.A.

#ifndef __ORL_DRIVER_H
#define __ORL_DRIVER_H

    #include <stdint.h>
    #include <stddef.h>
    #include "orl_util.h"

    /* Connection status */
    #define ORLD_ACTIVE          1
    #define ORLD_INACTIVE        0

    /* Functions */
    #ifdef __cplusplus
        extern "C" {
    #endif

        int ORLD_Initialize                    (int verbosity, unsigned int cntrl_idx, const char* LPC_addr, const char* cntrl_addr);
        int ORLD_Close                         (int verbosity, unsigned int cntrl_idx);

        int ORLD_CycleRead                     (int verbosity, unsigned int cntrl_idx);
        int ORLD_CycleWrite                    (int verbosity, unsigned int cntrl_idx);

        int ORLD_ClearNextPkg                  (int verbosity, unsigned int cntrl_idx);
        int ORLD_CheckOpenness                 (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, int* output);
        int ORLD_GetCommunicationState         (int verbosity, unsigned int cntrl_idx, int* output);
        int ORLD_GetSysID                      (int verbosity, unsigned int cntrl_idx, char* dest, size_t dest_sz);
        int ORLD_GetArmID                      (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, char* dest, size_t dest_sz);

        int ORLD_SetTargetPosMR                (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float value);
        int ORLD_SetTargetSpeedMRxStep         (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float value);
        int ORLD_SetExtInertiaDyn              (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float value);
        int ORLD_SetExtData                    (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float value);
        int ORLD_SetSpeedContributionMRxStep   (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float value);
        int ORLD_SetCurrentContribution        (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float value);
        int ORLD_SetFollowingError             (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx);
        int ORLD_SwitchToListenModality        (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx);
        int ORLD_SetExtForces                  (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, float value[6]);

        int ORLD_GetModeMasterAx               (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, int* output);
        int ORLD_GetStatusArm                  (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, int* output);
        int ORLD_GetModeAx                     (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, int* output);
        int ORLD_GetTargetPosMR                (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output);
        int ORLD_GetTargetSpeedMRxStep         (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output);
        int ORLD_GetMeasuredPosMR              (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output);
        int ORLD_GetMeasuredSpeedMRxStep       (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output);
        int ORLD_GetMeasuredCurrent            (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output);
        int ORLD_GetExtCurrentDyn              (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output);
        int ORLD_GetExtInertiaDyn              (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output);
        int ORLD_GetExtData                    (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, unsigned int axis_idx, float* output); 

        int ORLD_SrvGetFile                    (int verbosity, unsigned int cntrl_idx, const char* src_path, const char* dest_path);
        int ORLD_SrvGetRSreport                (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, const char* dest_path);
        int ORLD_SrvSetDrive                   (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, int cmd);
        int ORLD_SrvSetModality                (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, int req_jnt_mask, int modality, int en_addon_speed, int en_addon_curr);
        int ORLD_SrvSetFrame                   (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, int selection, float frame[6]);
        int ORLD_SrvSetPayload                 (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, float mass, float cog[3], float inertia[6]);
        int ORLD_SrvGetPayload                 (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, float* mass, float cog[3], float inertia[6]);
        int ORLD_SrvDeflCompJoint              (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, int cmd, float* jnt_pos, size_t jnt_pos_sz);
        int ORLD_SrvErrorReset                 (int verbosity, unsigned int cntrl_idx);
        int ORLD_SrvGetKinematicData           (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, float tx_rate[ORL_AXIS_MAX], float cal_data[ORL_AXIS_MAX], float ax_infl[ORL_AXIS_MAX]);
        int ORLD_SrvGetCDHParams               (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, float param_alpha[ORL_AXIS_MAX], float param_a[ORL_AXIS_MAX], float param_d[ORL_AXIS_MAX], float param_theta[ORL_AXIS_MAX], float param_bias[ORL_AXIS_MAX], int param_sign[ORL_AXIS_MAX]);
        int ORLD_SrvGetStrokeEnds              (int verbosity, unsigned int cntrl_idx, unsigned int arm_idx, float strend_soft_p[ORL_AXIS_MAX], float strend_soft_n[ORL_AXIS_MAX], float strend_hard_p[ORL_AXIS_MAX], float strend_hard_n[ORL_AXIS_MAX]);
        int ORLD_SrvGetModalStatus             (int verbosity, unsigned int cntrl_idx, int* modalStatus);

    #ifdef __cplusplus
        }
    #endif

#endif
