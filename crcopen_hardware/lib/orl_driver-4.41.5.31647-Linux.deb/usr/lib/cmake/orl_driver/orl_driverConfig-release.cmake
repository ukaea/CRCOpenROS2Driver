#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "orl_driver_SH" for configuration "Release"
set_property(TARGET orl_driver_SH APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(orl_driver_SH PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/liborl_driver.so.4.41.5.31647"
  IMPORTED_SONAME_RELEASE "liborl_driver.so.4"
  )

list(APPEND _IMPORT_CHECK_TARGETS orl_driver_SH )
list(APPEND _IMPORT_CHECK_FILES_FOR_orl_driver_SH "${_IMPORT_PREFIX}/lib/liborl_driver.so.4.41.5.31647" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
